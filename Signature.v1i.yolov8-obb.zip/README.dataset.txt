# Signature > 2025-01-28 10:30pm
https://universe.roboflow.com/project-knswz/signature-vjbsa

Provided by a Roboflow user
License: CC BY 4.0

